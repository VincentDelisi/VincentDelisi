<picture>
  <source media="(prefers-color-scheme: dark)" srcset="dark_mode.svg">
  <source media="(prefers-color-scheme: light)" srcset="light_mode.svg">
  <img alt="Vincent DeLisi — power trader and quant developer" src="dark_mode.svg">
</picture>
